# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""Utils methods definition."""
