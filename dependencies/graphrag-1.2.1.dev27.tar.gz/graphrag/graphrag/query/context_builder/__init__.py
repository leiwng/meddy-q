# Copyright (c) 2024 Microsoft Corporation.
# Licensed under the MIT License

"""Functions to build context for system prompt to generate responses for a user query."""
